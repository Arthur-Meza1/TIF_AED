# Multiple Files Example

This provides an example of including raylib-cpp.hpp in multiple files.
